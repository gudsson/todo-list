import { App } from './controller.js'

$(() => { let app = new App(); });